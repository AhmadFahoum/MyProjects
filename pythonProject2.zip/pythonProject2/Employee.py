class Employee:
    def __init__(self, name,age,department,gendel ,salary):
        self.name=name
        self.age=age
        self.department=department
        self.gendel=gendel
        self.salary=salary
 def check(self):
            if self.age>=60:
                self.salary+=500
                print(+str(self.salray))
            else:
                print("no bonus"+str(self.salary))


