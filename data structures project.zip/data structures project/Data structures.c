// Ahmad Fahoum
// 1213432
// sec:1
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h> // for isspace() and isdigit()

// Constants
#define MAX_SIZE 100
#define MAX_EQUATION_LENGTH 100



// Stack implementation
typedef struct Stack {
    int top;
    int array[MAX_SIZE];
} Stack;

Stack* createStack() {
    Stack* stack = (Stack*) malloc(sizeof(Stack)); // allocate memory for the stack
    stack->top = -1; // initialize top to -1
    return stack;
}

int isEmpty(Stack* stack) {
    return stack->top == -1; // return 1 if stack is empty, 0 otherwise
}

void push(Stack* stack, int item) {
    // check if stack is full
    if (stack->top == MAX_SIZE - 1) {
        printf("Stack overflow.\n");
        return;
    }
    // increment top and insert item
    stack->array[++stack->top] = item;
}

int pop(Stack* stack) {
    // check if stack is empty
    if (isEmpty(stack)) {
        printf("Stack is empty.\n");
        return -1;
    }
    return stack->array[stack->top--]; // return item and decrement top
}

int peek(Stack* stack) {
    // check if stack is empty
    if (isEmpty(stack)) {
        printf("Stack is empty.\n");
        return -1;
    }
    return stack->array[stack->top]; // return item at top
}

// Global variables
char equations[MAX_SIZE][MAX_EQUATION_LENGTH];
int equationCount = 0;

// Function to read equations from file
void readEquations(char* filename) {
    FILE* file = fopen(filename, "r");
    if (file == NULL) {
        printf("Failed to open file.\n");
        return;
    }

    while (fgets(equations[equationCount], MAX_EQUATION_LENGTH, file) != NULL) {
        equationCount++;
    }

    fclose(file);
}

void printEquations() {
    for (int i = 0; i < equationCount; i++) {
        printf("%d: %s", i+1, equations[i]);
    }
}

// Function to check the order of operators for infix to postfix conversion
int order(char op) {
    if (op == '+' || op == '-')
        return 1;
    if (op == '*' || op == '/' || op == '%')
        return 2;
    return 0;
}

// Function to convert infix expression to postfix expression
void infixToPostfix(char* infix, char* postfix) {
    // stack to store operators
    Stack* stack = createStack();
    int i, j = 0;

    // iterate over the infix equation
    for (i = 0; i < strlen(infix); i++) {
        if (isspace(infix[i])) {
            continue; // ignore white spaces
        } else if (isdigit(infix[i])) {
            // handle multi-digit numbers
            while (i < strlen(infix) && isdigit(infix[i])) {
                postfix[j++] = infix[i++];
            }
            postfix[j++] = ' '; // add space after number
            i--; // decrement i to handle the non-digit character in the next iteration
        } else if (infix[i] == '(') { // push '(' to stack
            push(stack, infix[i]);
        } else if (infix[i] == ')') { // pop until '(' is found
            while (!isEmpty(stack) && peek(stack) != '(') {
                postfix[j++] = pop(stack);
                postfix[j++] = ' '; // add space after operator
            }
            pop(stack); // pop '('
        } else {
            // pop operators with higher or equal order and add them to postfix
            while (!isEmpty(stack) && order(infix[i]) <= order(peek(stack))) { 
                postfix[j++] = pop(stack);
                postfix[j++] = ' '; // add space after operator
            }
            push(stack, infix[i]); // push the current operator to stack
        }
    }

    while (!isEmpty(stack)) { // pop remaining operators
        postfix[j++] = pop(stack);
        postfix[j++] = ' '; // add space after operator
    }

    postfix[j] = '\0'; // null-terminate the string
}

int evaluatePostfix(char* postfix) {
    // stack to store operands
    Stack* stack = createStack();
    char postfixCopy[100];
    strcpy(postfixCopy, postfix); // make a copy of the postfix expression

    // token to store each operand/operator
    char* token = strtok(postfixCopy, " ");
    while (token != NULL) {
        if (isdigit(token[0])) {
            push(stack, atoi(token)); // convert string to integer and push to stack
        } else {
            // pop two operands and perform the operation
            int operand2 = pop(stack); 
            int operand1 = pop(stack);
            switch (token[0]) {
                case '+': push(stack, operand1 + operand2); break;
                case '-': push(stack, operand1 - operand2); break;
                case '*': push(stack, operand1 * operand2); break;
                case '/': push(stack, operand1 / operand2); break;
                case '%': push(stack, operand1 % operand2); break;
            }
        }
        token = strtok(NULL, " "); // get the next token
    }

    int result = pop(stack); // pop the final result
    return result;
}

// Expression Tree

typedef struct TreeNode {
    char data[10];  // can hold up to 9-digit numbers
    struct TreeNode* left;
    struct TreeNode* right;
} TreeNode;

TreeNode* head = NULL;

typedef struct {
    int top;
    TreeNode** array;  // Array of TreeNode*
} treeStack;

treeStack* createTreeStack() {
    treeStack* stack = (treeStack*) malloc(sizeof(treeStack));
    stack->top = -1;
    stack->array = (TreeNode**) malloc(MAX_SIZE * sizeof(TreeNode*));  // Allocate memory for array of TreeNode*
    return stack;
}

TreeNode* createNode(char* token) {
    TreeNode* node = (TreeNode*) malloc(sizeof(TreeNode));
    strcpy(node->data, token);  // copy token into data field
    node->left = NULL;
    node->right = NULL;
    return node;
}

int isTreeEmpty(treeStack* stack) {
    return stack->top == -1;
}

void treePush(treeStack* stack, TreeNode* item) {
    // check if stack is full
    if (stack->top == MAX_SIZE - 1) {
        printf("Stack overflow.\n");
        return;
    }
    // increment top and insert item
    stack->array[++stack->top] = item;  
}

TreeNode* treePop(treeStack* stack) {
    // check if stack is empty
    if (isTreeEmpty(stack)) {
        printf("Stack is empty.\n");
        return NULL;
    }
    // return item and decrement top
    return stack->array[stack->top--]; 
}

TreeNode* postfixToExpressionTree(char* postfix) {
    treeStack* stack = createTreeStack();
    char postfixCopy[100];
    strcpy(postfixCopy, postfix); // make a copy of the postfix expression

    char* token = strtok(postfixCopy, " ");
    while (token != NULL) {
        TreeNode* node = createNode(token); // create a new node with the token

        if (isdigit(token[0])) {
            // If the token is an operand, push it to the stack
            treePush(stack, node);
        } else {
            // If the token is an operator, pop two nodes from the stack, make them
            // children of the current node, and push the current node to the stack
            node->right = treePop(stack);
            node->left = treePop(stack);
            treePush(stack, node);
        }

        token = strtok(NULL, " "); // get the next token
    }

    // The final node on the stack is the root of the expression tree
    TreeNode* root = treePop(stack);
    return root;
}

int evaluateExpressionTree(TreeNode* root) {
    if (root == NULL) {
        return 0;
    }

    // If the current node is a leaf node (i.e., an operand), return its value
    if (root->left == NULL && root->right == NULL) {
        return atoi(root->data);  // Convert char to int
    }

    // If the current node is an operator, recursively evaluate the left and right subtrees
    int leftValue = evaluateExpressionTree(root->left);
    int rightValue = evaluateExpressionTree(root->right);

    // Perform the operation and return the result
    switch (root->data[0]) {
        case '+': return leftValue + rightValue;
        case '-': return leftValue - rightValue;
        case '*': return leftValue * rightValue;
        case '/': return leftValue / rightValue;
        case '%': return leftValue % rightValue;
    }

    return 0;  // Should never reach here
}


int main() {
    int choice; // input
    int flag = 1; // flag to exit the loop
    char filename[] = "equations.txt"; // input file
    char postfix[MAX_EQUATION_LENGTH]; // to store postfix equations

    while (flag) {
        printf("\nMenu:\n");
        printf("1. Read equations\n");
        printf("2. Print equations\n");
        printf("3. Evaluate using Expression tree\n");
        printf("4. Print postfix expressions\n");
        printf("5. Save to output file (postfix and results)\n");
        printf("6. Exit\n");
        printf("Enter your choice: ");
        scanf("%d", &choice);

        switch (choice) {
            case 1:
                // read equations from file
                readEquations(filename);
                printf("Equations read successfully.\n");
                break;
            case 2:
                // print infix equations
                printf("------ Infix ------\n");
                printEquations();
                break;
            case 3:
                // evaluate equations using expression tree
                printf("\n------ Evaluation Results ------\n");
                for (int i = 0; i < equationCount; i++) {
                    infixToPostfix(equations[i], postfix);
                    TreeNode* root = postfixToExpressionTree(postfix);
                    int result = evaluateExpressionTree(root);
                    printf("Result of equation %d: %d\n", i+1, result);
                }
                break;
            case 4:
                // print postfix equations
                printf("\n------ Post fix ------\n");
                for (int i = 0; i < equationCount; i++) {
                    infixToPostfix(equations[i], postfix);
                    printf("%d: %s\n", i+1, postfix);
                }
                break;
            case 5:
                // save postfix equations and results to output file
                FILE *outputFile = fopen("results.txt", "w");
                if (outputFile == NULL) {
                    printf("Failed to open output file.\n");
                    break;
                }
                for (int i = 0; i < equationCount; i++) {
                    infixToPostfix(equations[i], postfix);
                    TreeNode* root = postfixToExpressionTree(postfix);
                    int result = evaluateExpressionTree(root);
                    fprintf(outputFile, "Postfix of equation %d: %s\n", i+1, postfix);
                    fprintf(outputFile, "Result of equation %d: %d\n", i+1, result);
                }
                fclose(outputFile);
                printf("Results saved to output file.\n");
                break;
            case 6:
                flag = 0; // Set flag to 0 to exit the loop
                break;
            default:
                // invalid choice
                printf("Invalid choice. Please enter a number between 1 and 6.\n");
        }
    }

    return 0;
}